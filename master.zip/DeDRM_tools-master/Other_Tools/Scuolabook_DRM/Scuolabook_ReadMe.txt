The latest Scuolabook tool can be found at Hex's own blog:
https://thisishex.wordpress.com/scuolabook-drm-remover/

Harper.